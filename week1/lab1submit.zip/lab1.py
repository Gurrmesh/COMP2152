
# Gurrmesh Singgh
elements = [1, 4, 7, 9]
a, b, c, d = 1, 2, 3, 4
e = (a * c) - (b / d)

e_complex = ((a - (b ** c)) // d) + (a % c)
temperature = 32.6

print(f"The temperature today is: {temperature:.3f} degrees Celsius")
userAge = int(input("Please enter your age: ")) + 22
print(f"Now showing the shop items filtered by age: {userAge}")
